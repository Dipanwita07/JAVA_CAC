package com.example;

import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

public class Main {

    public static void main(String[] args) {
        // Path to your CSV file
        String csvFile = "C:\\Users\\dipad\\OneDrive\\Desktop\\java\\cac\\cac\\src\\main\\resources\\cac_food.csv";

        // Create a scanner object to read user input
        Scanner scanner = new Scanner(System.in);
        int choice;
        // Display menu options
        do {
            System.out.println("Menu:");
            System.out.println("1. Show Dataset");
            System.out.println("2. Calculate Maximum Food Waste by Country");
            System.out.println("3. Calculate Correlation between Household and Retail Estimates");
            System.out.println("4. Calculate Standard Deviation for Specified Columns");
            System.out.println("5. Calculate Mean for Specified Columns");
            System.out.println("6. Calculate Median for Specified Columns");
            System.out.println("7. Calculate Mode for Specified Columns");
            System.out.println("8. Calculate Variance for Specified Columns");
            System.out.println("9. Hypothesis Testing");
            System.out.println("10. Visualize Data");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            // Read user choice
            choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    visualizeData(csvFile);
                    break;
                case 2:
                    calculateMaxWaste(csvFile);
                    break;
                case 3:
                    calculateCorrelation(csvFile);
                    break;
                case 4:
                    calculateStandardDeviation(csvFile);
                    break;
                case 5:
                    calculateMean(csvFile);
                    break;
                case 6:
                    calculateMedian(csvFile);
                    break;
                case 7:
                    calculateMode(csvFile);
                    break;
                case 8:
                    calculateVariance(csvFile);
                    break;
                case 9:
                    HypothesisTesting.performHypothesisTesting(csvFile);
                    break;
                case 10:
                    DataVisualization chart = new DataVisualization("Food Waste Statistics");
                    chart.pack();
                    chart.setVisible(true);
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 0);

        // Close the scanner
        scanner.close();
    }

    public static void visualizeData(String csvFile) {
        // Add visualization logic here
        System.out.println("Showing Data...");

        // Use try-with-resources to ensure resources are closed automatically
        try (FileReader fileReader = new FileReader(csvFile);
             CSVReader csvReader = new CSVReader(fileReader)) {

            // Read the header line
            String[] headers = csvReader.readNext();
            if (headers == null) {
                System.out.println("The CSV file is empty.");
                return;
            }

            // Print the header
            System.out.println(String.join(", ", headers));

            // Iterate over each record in the CSV file
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                // Print each record
                System.out.println(String.join(", ", values));
            }

        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        }
    }

    public static void calculateMaxWaste(String csvFile) {
        // Add calculation logic here
        System.out.println("Calculating Maximum Food Waste by Country...");

        // Use try-with-resources to ensure resources are closed automatically
        try (FileReader fileReader = new FileReader(csvFile);
             CSVReader csvReader = new CSVReader(fileReader)) {

            // Read the header line
            String[] headers = csvReader.readNext();
            if (headers == null) {
                System.out.println("The CSV file is empty.");
                return;
            }

            // Find the index of the columns we are interested in
            int countryIndex = -1;
            int combinedIndex = -1;

            for (int i = 0; i < headers.length; i++) {
                if (headers[i].trim().equals("Country")) {
                    countryIndex = i;
                } else if (headers[i].trim().equals("combined figures (kg/capita/year)")) {
                    combinedIndex = i;
                }
            }

            if (countryIndex == -1 || combinedIndex == -1) {
                System.out.println("Required columns not found in the dataset.");
                return;
            }

            String countryWithMaxWaste = "";
            double maxWaste = 0.0;

            // Iterate over each record in the CSV file
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                String country = values[countryIndex];
                double waste = Double.parseDouble(values[combinedIndex]);

                // Update the max waste and country if current value is higher
                if (waste > maxWaste) {
                    maxWaste = waste;
                    countryWithMaxWaste = country;
                }
            }

            // Print the result
            System.out.println("Country with the highest food-waste: " + countryWithMaxWaste);
            System.out.println("Waste value: " + maxWaste);

        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("Error parsing Waste value.");
            e.printStackTrace();
        }
    }

    public static void calculateCorrelation(String csvFile) {
        // Add correlation calculation logic here
        System.out.println("Calculating Correlation between Household and Retail Estimates...");

        // Use try-with-resources to ensure resources are closed automatically
        try (FileReader fileReader = new FileReader(csvFile);
             CSVReader csvReader = new CSVReader(fileReader)) {

            // Read the header line
            String[] headers = csvReader.readNext();
            if (headers == null) {
                System.out.println("The CSV file is empty.");
                return;
            }

            // Find the index of the columns for Household and Retail estimates
            int householdIndex = -1;
            int retailIndex = -1;

            for (int i = 0; i < headers.length; i++) {
                if (headers[i].trim().equals("Household estimate (kg/capita/year)")) {
                    householdIndex = i;
                } else if (headers[i].trim().equals("Retail estimate (kg/capita/year)")) {
                    retailIndex = i;
                }
            }

            if (householdIndex == -1 || retailIndex == -1) {
                System.out.println("Required columns not found in the dataset.");
                return;
            }

            // Variables for correlation calculation
            double sumHousehold = 0.0;
            double sumRetail = 0.0;
            double sumSquaredHousehold = 0.0;
            double sumSquaredRetail = 0.0;
            double sumProduct = 0.0;
            int count = 0;

            // Iterate over each record in the CSV file
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                double household = Double.parseDouble(values[householdIndex]);
                double retail = Double.parseDouble(values[retailIndex]);

                sumHousehold += household;
                sumRetail += retail;
                sumSquaredHousehold += household * household;
                sumSquaredRetail += retail * retail;
                sumProduct += household * retail;
                count++;
            }

            // Calculate correlation coefficient
            double numerator = sumProduct - (sumHousehold * sumRetail / count);
            double denominator = Math.sqrt((sumSquaredHousehold - (sumHousehold * sumHousehold / count)) * (sumSquaredRetail - (sumRetail * sumRetail / count)));
            double correlation = numerator / denominator;

            // Print the correlation coefficient
            System.out.println("Correlation coefficient: " + correlation);

        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("Error parsing values.");
            e.printStackTrace();
        }
    }

    public static void calculateStandardDeviation(String csvFile) {
        // Columns to calculate standard deviation for
        String[] columns = {
            "combined figures (kg/capita/year)", "Household estimate (kg/capita/year)", 
            "Retail estimate (kg/capita/year)", "Food service estimate (kg/capita/year)"
        };

        // Use try-with-resources to ensure resources are closed automatically
        try (FileReader fileReader = new FileReader(csvFile);
             CSVReader csvReader = new CSVReader(fileReader)) {

            // Read the header line
            String[] headers = csvReader.readNext();
            if (headers == null) {
                System.out.println("The CSV file is empty.");
                return;
            }

            // Find the index of the columns we are interested in
            Map<String, Integer> columnIndices = new HashMap<>();
            for (int i = 0; i < headers.length; i++) {
                for (String column : columns) {
                    if (headers[i].trim().equals(column)) {
                        columnIndices.put(column, i);
                    }
                }
            }

            if (columnIndices.size() != columns.length) {
                System.out.println("Required columns not found in the dataset.");
                return;
            }

            // Prepare a map to store values for each column
            Map<String, List<Double>> columnValues = new HashMap<>();
            for (String column : columns) {
                columnValues.put(column, new ArrayList<>());
            }

            // Iterate over each record in the CSV file
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                for (String column : columns) {
                    int index = columnIndices.get(column);
                    double value = Double.parseDouble(values[index]);
                    columnValues.get(column).add(value);
                }
            }

            // Calculate and print the standard deviation for each column
            for (String column : columns) {
                List<Double> valuesList = columnValues.get(column);
                double mean = valuesList.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
                double variance = valuesList.stream().mapToDouble(val -> Math.pow(val - mean, 2)).average().orElse(0.0);
                double standardDeviation = Math.sqrt(variance);
                System.out.println("Standard Deviation for " + column + ": " + standardDeviation);
            }

        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("Error parsing values.");
            e.printStackTrace();
        }
    }

    public static void calculateMean(String csvFile) {
        // Columns to calculate mean for
        String[] columns = {
            "combined figures (kg/capita/year)", "Household estimate (kg/capita/year)", 
            "Retail estimate (kg/capita/year)", "Food service estimate (kg/capita/year)"
        };

        // Use try-with-resources to ensure resources are closed automatically
        try (FileReader fileReader = new FileReader(csvFile);
             CSVReader csvReader = new CSVReader(fileReader)) {

            // Read the header line
            String[] headers = csvReader.readNext();
            if (headers == null) {
                System.out.println("The CSV file is empty.");
                return;
            }

            // Find the index of the columns we are interested in
            Map<String, Integer> columnIndices = new HashMap<>();
            for (int i = 0; i < headers.length; i++) {
                for (String column : columns) {
                    if (headers[i].trim().equals(column)) {
                        columnIndices.put(column, i);
                    }
                }
            }

            if (columnIndices.size() != columns.length) {
                System.out.println("Required columns not found in the dataset.");
                return;
            }

            // Prepare a map to store values for each column
            Map<String, List<Double>> columnValues = new HashMap<>();
            for (String column : columns) {
                columnValues.put(column, new ArrayList<>());
            }

            // Iterate over each record in the CSV file
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                for (String column : columns) {
                    int index = columnIndices.get(column);
                    double value = Double.parseDouble(values[index]);
                    columnValues.get(column).add(value);
                }
            }

            // Calculate and print the mean for each column
            for (String column : columns) {
                List<Double> valuesList = columnValues.get(column);
                double mean = valuesList.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
                System.out.println("Mean for " + column + ": " + mean);
            }

        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("Error parsing values.");
            e.printStackTrace();
        }
    }

    public static void calculateMedian(String csvFile) {
    // Columns to calculate median for
    String[] columns = {
        "combined figures (kg/capita/year)", "Household estimate (kg/capita/year)", 
        "Retail estimate (kg/capita/year)", "Food service estimate (kg/capita/year)"
    };

    // Use try-with-resources to ensure resources are closed automatically
    try (FileReader fileReader = new FileReader(csvFile);
         CSVReader csvReader = new CSVReader(fileReader)) {

        // Read the header line
        String[] headers = csvReader.readNext();
        if (headers == null) {
            System.out.println("The CSV file is empty.");
            return;
        }

        // Find the index of the columns we are interested in
        Map<String, Integer> columnIndices = new HashMap<>();
        for (int i = 0; i < headers.length; i++) {
            for (String column : columns) {
                if (headers[i].trim().equals(column)) {
                    columnIndices.put(column, i);
                }
            }
        }

        if (columnIndices.size() != columns.length) {
            System.out.println("Required columns not found in the dataset.");
            return;
        }

        // Prepare a map to store values for each column
        Map<String, List<Double>> columnValues = new HashMap<>();
        for (String column : columns) {
            columnValues.put(column, new ArrayList<>());
        }

        // Iterate over each record in the CSV file
        String[] values;
        while ((values = csvReader.readNext()) != null) {
            for (String column : columns) {
                int index = columnIndices.get(column);
                double value = Double.parseDouble(values[index]);
                columnValues.get(column).add(value);
            }
        }

        // Calculate and print the median for each column
        for (String column : columns) {
            List<Double> valuesList = columnValues.get(column);
            Collections.sort(valuesList);
            double median;
            int size = valuesList.size();
            if (size % 2 == 0) {
                median = (valuesList.get(size / 2 - 1) + valuesList.get(size / 2)) / 2;
            } else {
                median = valuesList.get(size / 2);
            }
            System.out.println("Median for " + column + ": " + median);
        }

    } catch (IOException | CsvValidationException e) {
        e.printStackTrace();
    } catch (NumberFormatException e) {
        System.err.println("Error parsing values.");
        e.printStackTrace();
    }
}
public static void calculateMode(String csvFile) {
    // Columns to calculate mode for
    String[] columns = {
        "combined figures (kg/capita/year)", "Household estimate (kg/capita/year)", 
        "Retail estimate (kg/capita/year)", "Food service estimate (kg/capita/year)"
    };

    // Use try-with-resources to ensure resources are closed automatically
    try (FileReader fileReader = new FileReader(csvFile);
         CSVReader csvReader = new CSVReader(fileReader)) {

        // Read the header line
        String[] headers = csvReader.readNext();
        if (headers == null) {
            System.out.println("The CSV file is empty.");
            return;
        }

        // Find the index of the columns we are interested in
        Map<String, Integer> columnIndices = new HashMap<>();
        for (int i = 0; i < headers.length; i++) {
            for (String column : columns) {
                if (headers[i].trim().equals(column)) {
                    columnIndices.put(column, i);
                }
            }
        }

        if (columnIndices.size() != columns.length) {
            System.out.println("Required columns not found in the dataset.");
            return;
        }

        // Prepare a map to store values for each column
        Map<String, List<Double>> columnValues = new HashMap<>();
        for (String column : columns) {
            columnValues.put(column, new ArrayList<>());
        }

        // Iterate over each record in the CSV file
        String[] values;
        while ((values = csvReader.readNext()) != null) {
            for (String column : columns) {
                int index = columnIndices.get(column);
                double value = Double.parseDouble(values[index]);
                columnValues.get(column).add(value);
            }
        }

        // Calculate and print the mode for each column
        for (String column : columns) {
            List<Double> valuesList = columnValues.get(column);
            Map<Double, Integer> frequencyMap = new HashMap<>();
            for (double value : valuesList) {
                frequencyMap.put(value, frequencyMap.getOrDefault(value, 0) + 1);
            }
            double mode = valuesList.get(0);
            int maxCount = 0;
            for (Map.Entry<Double, Integer> entry : frequencyMap.entrySet()) {
                if (entry.getValue() > maxCount) {
                    maxCount = entry.getValue();
                    mode = entry.getKey();
                }
            }
            System.out.println("Mode for " + column + ": " + mode);
        }

    } catch (IOException | CsvValidationException e) {
        e.printStackTrace();
    } catch (NumberFormatException e) {
        System.err.println("Error parsing values.");
        e.printStackTrace();
    }
}

public static void calculateVariance(String csvFile) {
    // Columns to calculate variance for
    String[] columns = {
        "combined figures (kg/capita/year)", "Household estimate (kg/capita/year)", 
        "Retail estimate (kg/capita/year)", "Food service estimate (kg/capita/year)"
    };

    // Use try-with-resources to ensure resources are closed automatically
    try (FileReader fileReader = new FileReader(csvFile);
         CSVReader csvReader = new CSVReader(fileReader)) {

        // Read the header line
        String[] headers = csvReader.readNext();
        if (headers == null) {
            System.out.println("The CSV file is empty.");
            return;
        }

        // Find the index of the columns we are interested in
        Map<String, Integer> columnIndices = new HashMap<>();
        for (int i = 0; i < headers.length; i++) {
            for (String column : columns) {
                if (headers[i].trim().equals(column)) {
                    columnIndices.put(column, i);
                }
            }
        }

        if (columnIndices.size() != columns.length) {
            System.out.println("Required columns not found in the dataset.");
            return;
        }

        // Prepare a map to store values for each column
        Map<String, List<Double>> columnValues = new HashMap<>();
        for (String column : columns) {
            columnValues.put(column, new ArrayList<>());
        }

        // Iterate over each record in the CSV file
        String[] values;
        while ((values = csvReader.readNext()) != null) {
            for (String column : columns) {
                int index = columnIndices.get(column);
                double value = Double.parseDouble(values[index]);
                columnValues.get(column).add(value);
            }
        }

        // Calculate and print the variance for each column
        for (String column : columns) {
            List<Double> valuesList = columnValues.get(column);
            double mean = valuesList.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
            double variance = valuesList.stream().mapToDouble(val -> Math.pow(val - mean, 2)).average().orElse(0.0);
            System.out.println("Variance for " + column + ": " + variance);
        }

    } catch (IOException | CsvValidationException e) {
        e.printStackTrace();
    } catch (NumberFormatException e) {
        System.err.println("Error parsing values.");
        e.printStackTrace();
    }
}


}
