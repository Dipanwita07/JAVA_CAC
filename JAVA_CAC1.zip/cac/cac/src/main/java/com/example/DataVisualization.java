package com.example;

import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.awt.Font;

public class DataVisualization extends ApplicationFrame {

    public DataVisualization(String applicationTitle) {
        super(applicationTitle);
    }

    private JFreeChart createBarChart(String chartTitle) {
        JFreeChart barChart = ChartFactory.createBarChart(
                chartTitle,
                "Country",
                "Household estimate (kg/capita/year)",
                createHouseholdEstimateDataset(),
                PlotOrientation.VERTICAL,
                true, true, false);

        CategoryPlot plot = (CategoryPlot) barChart.getPlot();
        CategoryAxis domainAxis = plot.getDomainAxis();
        domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
        domainAxis.setTickLabelFont(new Font("SansSerif", Font.PLAIN, 10));

        return barChart;
    }

    private JFreeChart createPieChart(String chartTitle) {
        DefaultPieDataset pieDataset = new DefaultPieDataset();
        Map<String, Double> data = createRetailEstimateData();

        data.forEach(pieDataset::setValue);

        JFreeChart pieChart = ChartFactory.createPieChart(
                chartTitle,
                pieDataset,
                true, true, false);

        PiePlot plot = (PiePlot) pieChart.getPlot();
        plot.setSimpleLabels(true);

        return pieChart;
    }

    private JFreeChart createStackedBarChart(String chartTitle) {
        JFreeChart stackedBarChart = ChartFactory.createStackedBarChart(
                chartTitle,
                "Country",
                "Estimates (kg/capita/year)",
                createCombinedHouseholdDataset(),
                PlotOrientation.VERTICAL,
                true, true, false);

        CategoryPlot plot = (CategoryPlot) stackedBarChart.getPlot();
        CategoryAxis domainAxis = plot.getDomainAxis();
        domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
        domainAxis.setTickLabelFont(new Font("SansSerif", Font.PLAIN, 10));

        return stackedBarChart;
    }

    private JFreeChart createAreaChart(String chartTitle) {
        JFreeChart areaChart = ChartFactory.createAreaChart(
                chartTitle,
                "Country",
                "Food service estimate (kg/capita/year)",
                createFoodServiceEstimateDataset(),
                PlotOrientation.VERTICAL,
                true, true, false);

        return areaChart;
    }

    private JFreeChart createRegionPieChart(String chartTitle) {
        DefaultPieDataset pieDataset = new DefaultPieDataset();
        Map<String, Double> data = createRegionDistributionData();

        data.forEach(pieDataset::setValue);

        JFreeChart pieChart = ChartFactory.createPieChart(
                chartTitle,
                pieDataset,
                true, true, false);

        PiePlot plot = (PiePlot) pieChart.getPlot();
        plot.setSimpleLabels(true);

        return pieChart;
    }

    private DefaultCategoryDataset createHouseholdEstimateDataset() {
        String csvFile = "C:\\Users\\dipad\\OneDrive\\Desktop\\java\\cac\\cac\\src\\main\\resources\\cac_food.csv";
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try (FileReader fileReader = new FileReader(csvFile);
             CSVReader csvReader = new CSVReader(fileReader)) {

            String[] headers = csvReader.readNext();
            if (headers == null) {
                System.out.println("The CSV file is empty.");
                return dataset;
            }

            Map<String, Integer> columnIndices = new HashMap<>();
            for (int i = 0; i < headers.length; i++) {
                columnIndices.put(headers[i].trim(), i);
            }

            List<String[]> rows = new ArrayList<>();
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                rows.add(values);
            }

            rows.stream()
                .sorted((a, b) -> Double.compare(
                        Double.parseDouble(b[columnIndices.get("Household estimate (kg/capita/year)")]),
                        Double.parseDouble(a[columnIndices.get("Household estimate (kg/capita/year)")])))
                .limit(10)
                .forEach(row -> {
                    String country = row[columnIndices.get("Country")];
                    double householdEstimate = Double.parseDouble(row[columnIndices.get("Household estimate (kg/capita/year)")]);
                    dataset.addValue(householdEstimate, "Household estimate", country);
                });

        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        }

        return dataset;
    }

    private Map<String, Double> createRetailEstimateData() {
        String csvFile = "C:\\Users\\dipad\\OneDrive\\Desktop\\java\\cac\\cac\\src\\main\\resources\\cac_food.csv";
        Map<String, Double> data = new HashMap<>();

        try (FileReader fileReader = new FileReader(csvFile);
             CSVReader csvReader = new CSVReader(fileReader)) {

            String[] headers = csvReader.readNext();
            if (headers == null) {
                System.out.println("The CSV file is empty.");
                return data;
            }

            Map<String, Integer> columnIndices = new HashMap<>();
            for (int i = 0; headers != null && i < headers.length; i++) {
                columnIndices.put(headers[i].trim(), i);
            }

            List<String[]> rows = new ArrayList<>();
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                rows.add(values);
            }

            rows.stream()
                .sorted((a, b) -> Double.compare(
                        Double.parseDouble(b[columnIndices.get("Retail estimate (kg/capita/year)")]),
                        Double.parseDouble(a[columnIndices.get("Retail estimate (kg/capita/year)")])))
                .limit(10)
                .forEach(row -> {
                    String country = row[columnIndices.get("Country")];
                    double retailEstimate = Double.parseDouble(row[columnIndices.get("Retail estimate (kg/capita/year)")]);
                    data.put(country, retailEstimate);
                });

        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        }

        return data;
    }

    private DefaultCategoryDataset createCombinedHouseholdDataset() {
        String csvFile = "C:\\Users\\dipad\\OneDrive\\Desktop\\java\\cac\\cac\\src\\main\\resources\\cac_food.csv";
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try (FileReader fileReader = new FileReader(csvFile);
             CSVReader csvReader = new CSVReader(fileReader)) {

            String[] headers = csvReader.readNext();
            if (headers == null) {
                System.out.println("The CSV file is empty.");
                return dataset;
            }

            Map<String, Integer> columnIndices = new HashMap<>();
            for (int i = 0; i < headers.length; i++) {
                columnIndices.put(headers[i].trim(), i);
            }

            List<String[]> rows = new ArrayList<>();
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                rows.add(values);
            }

            rows.stream()
                .sorted((a, b) -> Double.compare(
                        Double.parseDouble(b[columnIndices.get("Household estimate (kg/capita/year)")]),
                        Double.parseDouble(a[columnIndices.get("Household estimate (kg/capita/year)")])))
                .limit(10)
                .forEach(row -> {
                    String country = row[columnIndices.get("Country")];
                    double householdEstimate = Double.parseDouble(row[columnIndices.get("Household estimate (kg/capita/year)")]);
                    double combinedFigures = Double.parseDouble(row[columnIndices.get("combined figures (kg/capita/year)")]);
                    dataset.addValue(householdEstimate, "Household estimate", country);
                    dataset.addValue(combinedFigures, "Combined figures", country);
                });

        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        }

        return dataset;
    }

    private DefaultCategoryDataset createFoodServiceEstimateDataset() {
        String csvFile = "C:\\Users\\dipad\\OneDrive\\Desktop\\java\\cac\\cac\\src\\main\\resources\\cac_food.csv";
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try (FileReader fileReader = new FileReader(csvFile);
             CSVReader csvReader = new CSVReader(fileReader)) {

            String[] headers = csvReader.readNext();
            if (headers == null) {
                System.out.println("The CSV file is empty.");
                return dataset;
            }

            Map<String, Integer> columnIndices = new HashMap<>();
            for (int i = 0; i < headers.length; i++) {
                columnIndices.put(headers[i].trim(), i);
            }

            List<String[]> rows = new ArrayList<>();
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                rows.add(values);
            }

            rows.stream()
                .sorted((a, b) -> Double.compare(
                        Double.parseDouble(b[columnIndices.get("Food service estimate (kg/capita/year)")]),
                        Double.parseDouble(a[columnIndices.get("Food service estimate (kg/capita/year)")])))
                .limit(10)
                .forEach(row -> {
                    String country = row[columnIndices.get("Country")];
                    double foodServiceEstimate = Double.parseDouble(row[columnIndices.get("Food service estimate (kg/capita/year)")]);
                    dataset.addValue(foodServiceEstimate, "Food service estimate", country);
                });

        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        }

        return dataset;
    }

    private Map<String, Double> createRegionDistributionData() {
        String csvFile = "C:\\Users\\dipad\\OneDrive\\Desktop\\java\\cac\\cac\\src\\main\\resources\\cac_food.csv";
        Map<String, Double> data = new HashMap<>();

        try (FileReader fileReader = new FileReader(csvFile);
             CSVReader csvReader = new CSVReader(fileReader)) {

            String[] headers = csvReader.readNext();
            if (headers == null) {
                System.out.println("The CSV file is empty.");
                return data;
            }

            Map<String, Integer> columnIndices = new HashMap<>();
            for (int i = 0; headers != null && i < headers.length; i++) {
                columnIndices.put(headers[i].trim(), i);
            }

            List<String[]> rows = new ArrayList<>();
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                rows.add(values);
            }

            rows.forEach(row -> {
                String region = row[columnIndices.get("Region")];
                double householdEstimate = Double.parseDouble(row[columnIndices.get("Household estimate (kg/capita/year)")]);
                data.put(region, data.getOrDefault(region, 0.0) + householdEstimate);
            });

        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        }

        return data;
    }

    public static void main(String[] args) {
        DataVisualization barChartApp = new DataVisualization("Bar Chart");
        JFreeChart barChart = barChartApp.createBarChart("Top 10 Countries by Household Estimate");
        ChartPanel barChartPanel = new ChartPanel(barChart);
        ApplicationFrame barChartFrame = new ApplicationFrame("Bar Chart");
        barChartFrame.setContentPane(barChartPanel);
        barChartFrame.pack();
        RefineryUtilities.centerFrameOnScreen(barChartFrame);
        barChartFrame.setVisible(true);

        DataVisualization pieChartApp = new DataVisualization("Pie Chart");
        JFreeChart pieChart = pieChartApp.createPieChart("Distribution by Retail Estimate");
        ChartPanel pieChartPanel = new ChartPanel(pieChart);
        ApplicationFrame pieChartFrame = new ApplicationFrame("Pie Chart");
        pieChartFrame.setContentPane(pieChartPanel);
        pieChartFrame.pack();
        RefineryUtilities.centerFrameOnScreen(pieChartFrame);
        pieChartFrame.setVisible(true);

        DataVisualization stackedBarChartApp = new DataVisualization("Stacked Bar Chart");
        JFreeChart stackedBarChart = stackedBarChartApp.createStackedBarChart("Combined Figures and Household Estimates");
        ChartPanel stackedBarChartPanel = new ChartPanel(stackedBarChart);
        ApplicationFrame stackedBarChartFrame = new ApplicationFrame("Stacked Bar Chart");
        stackedBarChartFrame.setContentPane(stackedBarChartPanel);
        stackedBarChartFrame.pack();
        RefineryUtilities.centerFrameOnScreen(stackedBarChartFrame);
        stackedBarChartFrame.setVisible(true);

        DataVisualization areaChartApp = new DataVisualization("Area Chart");
        JFreeChart areaChart = areaChartApp.createAreaChart("Food Service Estimates by Country");
        ChartPanel areaChartPanel = new ChartPanel(areaChart);
        ApplicationFrame areaChartFrame = new ApplicationFrame("Area Chart");
        areaChartFrame.setContentPane(areaChartPanel);
        areaChartFrame.pack();
        RefineryUtilities.centerFrameOnScreen(areaChartFrame);
        areaChartFrame.setVisible(true);

        DataVisualization regionPieChartApp = new DataVisualization("Region Pie Chart");
        JFreeChart regionPieChart = regionPieChartApp.createRegionPieChart("Distribution by Region");
        ChartPanel regionPieChartPanel = new ChartPanel(regionPieChart);
        ApplicationFrame regionPieChartFrame = new ApplicationFrame("Region Pie Chart");
        regionPieChartFrame.setContentPane(regionPieChartPanel);
        regionPieChartFrame.pack();
        RefineryUtilities.centerFrameOnScreen(regionPieChartFrame);
        regionPieChartFrame.setVisible(true);
    }
}
