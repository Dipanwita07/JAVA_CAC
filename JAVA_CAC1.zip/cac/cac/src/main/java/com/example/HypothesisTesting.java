package com.example;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import org.apache.commons.math3.stat.inference.ChiSquareTest;
import org.apache.commons.math3.stat.inference.OneWayAnova;
import org.apache.commons.math3.stat.inference.TTest;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HypothesisTesting {

    public static void performHypothesisTesting(String csvFile) {
        try (FileReader fileReader = new FileReader(csvFile);
             CSVReader csvReader = new CSVReader(fileReader)) {

            // Read the header line
            String[] headers = csvReader.readNext();
            if (headers == null) {
                System.out.println("The CSV file is empty.");
                return;
            }

            // Find the index of the columns we are interested in
            int householdIndex = -1;
            int retailIndex = -1;
            int foodServiceIndex = -1;

            for (int i = 0; i < headers.length; i++) {
                if (headers[i].trim().equals("Household estimate (kg/capita/year)")) {
                    householdIndex = i;
                } else if (headers[i].trim().equals("Retail estimate (kg/capita/year)")) {
                    retailIndex = i;
                } else if (headers[i].trim().equals("Food service estimate (kg/capita/year)")) {
                    foodServiceIndex = i;
                }
            }

            if (householdIndex == -1 || retailIndex == -1 || foodServiceIndex == -1) {
                System.out.println("Required columns not found in the dataset.");
                return;
            }

            List<Double> householdValues = new ArrayList<>();
            List<Double> retailValues = new ArrayList<>();
            List<Double> foodServiceValues = new ArrayList<>();

            // Iterate over each record in the CSV file
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                double householdValue = Double.parseDouble(values[householdIndex]);
                double retailValue = Double.parseDouble(values[retailIndex]);
                double foodServiceValue = Double.parseDouble(values[foodServiceIndex]);

                householdValues.add(householdValue);
                retailValues.add(retailValue);
                foodServiceValues.add(foodServiceValue);
            }

            // Perform hypothesis testing
            performChiSquareTest(householdValues, retailValues, foodServiceValues);
            performTTest(householdValues, retailValues);
            performAnova(householdValues, retailValues, foodServiceValues);

        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("Error parsing values.");
            e.printStackTrace();
        }
    }

    public static void performChiSquareTest(List<Double> householdValues, List<Double> retailValues, List<Double> foodServiceValues) {
        // Convert the observed values to long
        long[][] observed = new long[3][householdValues.size()];
        for (int i = 0; i < householdValues.size(); i++) {
            observed[0][i] = Math.round(householdValues.get(i));
            observed[1][i] = Math.round(retailValues.get(i));
            observed[2][i] = Math.round(foodServiceValues.get(i));
        }

        // Perform chi-square test for independence
        ChiSquareTest chiSquareTest = new ChiSquareTest();
        double pValue = chiSquareTest.chiSquareTest(observed);

        System.out.println("P-value for the Chi-Square test: " + pValue);
        if (pValue < 0.05) {
            System.out.println("Reject the null hypothesis. There is a significant association between the variables.");
        } else {
            System.out.println("Fail to reject the null hypothesis. There is no significant association between the variables.");
        }
    }

    public static void performTTest(List<Double> data1, List<Double> data2) {
        double[] sample1 = data1.stream().mapToDouble(Double::doubleValue).toArray();
        double[] sample2 = data2.stream().mapToDouble(Double::doubleValue).toArray();

        TTest tTest = new TTest();
        double pValue = tTest.tTest(sample1, sample2);

        System.out.println("P-value for the two-sample T-test: " + pValue);
        if (pValue < 0.05) {
            System.out.println("Reject the null hypothesis. There is a significant difference between the two groups.");
        } else {
            System.out.println("Fail to reject the null hypothesis. There is no significant difference between the two groups.");
        }
    }

    public static void performAnova(List<Double> householdValues, List<Double> retailValues, List<Double> foodServiceValues) {
        // Convert lists to arrays
        double[] householdArray = householdValues.stream().mapToDouble(Double::doubleValue).toArray();
        double[] retailArray = retailValues.stream().mapToDouble(Double::doubleValue).toArray();
        double[] foodServiceArray = foodServiceValues.stream().mapToDouble(Double::doubleValue).toArray();

        // Create a list of double arrays
        List<double[]> data = new ArrayList<>();
        data.add(householdArray);
        data.add(retailArray);
        data.add(foodServiceArray);

        OneWayAnova anova = new OneWayAnova();
        double pValue = anova.anovaPValue(data);

        System.out.println("P-value for the ANOVA test: " + pValue);
        if (pValue < 0.05) {
            System.out.println("Reject the null hypothesis. There is a significant difference between the groups.");
        } else {
            System.out.println("Fail to reject the null hypothesis. There is no significant difference between the groups.");
        }
    }
}
